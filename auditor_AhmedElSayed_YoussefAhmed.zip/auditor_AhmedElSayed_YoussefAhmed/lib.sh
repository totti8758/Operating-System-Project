# Checks if the target directory exists, if not it exists with an error
require_dir() {
	if [ ! -d "$1" ]; then
		echo "Error: Directory '$1' does not exist." >&2
		exit 1
	fi
}

# Logs an action done with a timestamp into the auditor.log (every single action that's been done)
log_action() {
	local action="$1"
	echo "$(date '+%Y-%m-%d %H:%M:%S') - $action" >> auditor.log
}

# Prints an informational message of whatever action that was completed and logs it into auditor.log
log_info() {
	local message="$1"
	echo "[INFO] $message"
	echo "$(date '+%Y-%m-%d %H:%M:%S') - [INFO] $message" >> auditor.log
}

# Prints an error message into standard error (stderr) and logs it into the auditor.log
log_error() {
	local err_message="$1"
	echo "Error: $err_message" >&2
	echo "$(date '+%Y-%m-%d %H:%M:%S') - [ERROR] $err_message" >> auditor.log
}
