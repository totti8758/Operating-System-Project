# Loads functions from lib.sh
source "$(dirname "$0")/lib.sh"

TARGET_DIR="${1:-.}"
require_dir "$TARGET_DIR"

# Scans the entire directory, lists all files and folders
scan_directory() {
	local target="$1"
	local file_count=0
	local dir_count=0

	for item in "$target"/*; do
		if [ -f "$item" ]; then
			echo "[file] $(basename "$item")"
			((file_count++))
		elif [ -d "$item" ]; then
			echo "[dir] $(basename "$item")"
			((dir_count++))
		fi
	done

	echo "Files: $file_count"
	echo "Folders: $dir_count"
	log_action "Scanned directory: $target"
}

# Prints all permissions (read, write, executable)  for each file
permission_audit() {
	local target="$1"
	local unreadable=0
	local executable=0

	for f in "$target"/*; do
		if [ -f "$f" ]; then
			local p_str=""
			if [ -r "$f" ]; then p_str="r"; else p_str="${p_str}-"; fi
			if [ -w "$f" ]; then p_str="${p_str}w"; else p_str="${p_str}-"; fi
			if [ -x "$f" ]; then
				p_str="${p_str}x"
				((executable++))
			else
				p_str="${p_str}-"
			fi

			echo "$p_str $(basename "$f")"

			if [ ! -r "$f" ]; then
				((unreadable++))
			fi
		fi
	done

	echo "Unreadable files: $unreadable Executable files: $executable"
	log_action "Performed permission audit on $target"
}

# Counts each type of extensions and prints them
extension_report() {
	local target="$1"
	declare -A ext_counts=([txt]=0 [log]=0 [sh]=0 [jpg]=0 [other]=0)

	for f in "$target"/*; do
		if [ -f "$f" ]; then
			local filename=$(basename "$f")
			local ext="${filename##*.}"

			if [[ "$filename" != *.* ]] || [[ -z "${ext_counts[$ext]}" ]]; then
				((ext_counts[other]++))
			else
				((ext_counts[$ext]++))
			fi
		fi
	done

	echo "Extension report:"
	for ext in "${!ext_counts[@]}"; do
		echo "$ext : ${ext_counts[$ext]}"
	done
	log_action "Generated extension report for $target"
}

# Searchs for a specific file(s) by using a keyword
search_file() {
	local target="$1"
	echo -n "Enter search text: "
	read query
	local found=0

	for f in "$target"/*; do
		if [ -f "$f" ]; then
			local fname=$(basename "$f")
			if [[ "$fname" == *"$query"* ]]; then
				echo "$fname"
				found=1
			fi
		fi
	done

	if [ $found -eq 0 ]; then
		echo "No files match your search."
	fi
	log_action "Searched for '$query' in $target"
}

# Backup all readable files (doesn't include unreadable files that have no permission) into a backup folder with their timestamps
backup_all() {
	local target="$1"
	local backup_dir="backups"
	mkdir -p "$backup_dir"

	local saved=0
	local skipped=0
	local timestamp=$(date '+%Y%m%d_%H%M%S')

	for f in "$target"/*; do
		if [ -f "$f" ]; then
			if [ -r "$f" ]; then
				local bname=$(basename "$f")
				cp "$f" "$backup_dir/${bname}_${timestamp}.bak"
				((saved++))
			else
				echo "Error: Cannot read $(basename "$f"), skipping." >&2
				((skipped++))
			fi
		fi
	done

	echo "Saved: $saved, Skipped: $skipped"
	log_action "Backed up $saved files from $target"
}

# Lists and prints all backed up files (if there are any)
list_backups() {
	local backup_dir="backups"
	if [ ! -d "$backup_dir" ] || [ -z "$(ls -A "$backup_dir" 2>/dev/null)" ]; then
		echo "(no backups yet)"
	else
		ls -1 "$backup_dir"
	fi
	log_action "Listed backups"
}

# Restores files from backup folder into the sample_data folder without replacing the originals
restore_backup() {
	local target="$1"
	local backup_dir="backups"

	echo -n "Enter backup filename to restore: "
	read bfile

	if [ ! -f "$backup_dir/$bfile" ]; then
		echo "Error: Backup file '$bfile' does not exist." >&2
		return 1
	fi

	cp "$backup_dir/$bfile" "$target/restored_$bfile"
	echo "Restored $bfile as restored_$bfile in $target"
	log_action "Restored backup $bfile"
}

# Handles command line argument use if passed directly
if [ -n "$2" ]; then
	case "$2" in
		scan) scan_directory "$TARGET_DIR" ;;
		perms) permission_audit "$TARGET_DIR" ;;
		ext) extension_report "$TARGET_DIR" ;;
		backup) backup_all "$TARGET_DIR" ;;
		*) echo "Unknown command-line action: $2"; exit 1 ;;
	esac
	exit 0
fi

# Main menu loop
while true; do
	echo ""
	echo "=== File Auditor & Backup Tool ==="
	echo "1. Scan directory"
	echo "2. Permission audit"
	echo "3. Extension report"
	echo "4. Search file"
	echo "5. Backup all files"
	echo "6. List backups"
	echo "7. Restore backup"
	echo "8. Exit"
	echo -n "Choose an option [1-8]: "
	read choice

	case $choice in
		1) scan_directory "$TARGET_DIR" ;;
		2) permission_audit "$TARGET_DIR" ;;
		3) extension_report "$TARGET_DIR" ;;
		4) search_file "$TARGET_DIR" ;;
		5) backup_all "$TARGET_DIR" ;;
		6) list_backups ;;
		7) restore_backup "$TARGET_DIR" ;;
		8) echo "Exiting."; exit 0 ;;
		*) echo "Error: Invalid choice. Please choose between 1 and 8." ;;
	esac
done
