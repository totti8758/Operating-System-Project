File Auditor & Backup Tool
Team Members:
Ahmed El Sayed Abdel Ghani: Wrote parts of the auditor.sh file which are the search_file(), backup_all(), list_backups(), and restore_backup() functions, including
the main menu loop.
Youssef Ahmed Abdel Fatah: Wrote the entire lib.sh file, including parts of the auditor.sh file which are the scan_directory(), permission_audit(), and
extension_report().

How to run:
1. Interactive menu: ./auditor.sh <target_directory>
2. Direct CLI action: ./auditor.sh <target_directory> <scan|perms|ext|backup>
